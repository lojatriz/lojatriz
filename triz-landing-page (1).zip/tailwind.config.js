module.exports = {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        olive: {
          600: '#556B2F',
        },
      },
    },
  },
  plugins: [],
}