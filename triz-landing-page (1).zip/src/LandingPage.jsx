export default function LandingPage() {
  return (
    <div className="min-h-screen bg-white text-neutral-900 flex flex-col items-center justify-center px-4 py-10">
      <div className="max-w-xl text-center space-y-6">
        <h1 className="text-4xl font-bold">Ganhe 10% OFF na sua primeira compra!</h1>
        <p className="text-lg text-neutral-600">
          Receba um cupom exclusivo e descubra o estilo TRIZ: moda casual, vibrante e confortável, feita pra quem vive o agora.
        </p>
        <img
          src="/modelo-triz.jpg"
          alt="Modelo vestindo TRIZ"
          className="rounded-2xl shadow-md w-full object-cover"
        />
        <form className="space-y-4 mt-6">
          <input
            type="text"
            placeholder="Seu nome"
            className="w-full border border-neutral-300 rounded-xl px-4 py-2 focus:outline-none focus:ring-2 focus:ring-olive-600"
          />
          <input
            type="email"
            placeholder="Seu e-mail"
            className="w-full border border-neutral-300 rounded-xl px-4 py-2 focus:outline-none focus:ring-2 focus:ring-olive-600"
          />
          <button
            type="submit"
            className="w-full bg-green-700 text-white py-2 rounded-xl font-semibold hover:bg-green-800 transition"
          >
            Quero meu cupom
          </button>
          <p className="text-xs text-neutral-500">
            Ao se cadastrar, você concorda com nossa política de privacidade.
          </p>
        </form>
        <div className="flex justify-around mt-10 text-sm text-neutral-600">
          <div>
            <span className="block font-semibold">Envio rápido</span>
          </div>
          <div>
            <span className="block font-semibold">Moda consciente</span>
          </div>
          <div>
            <span className="block font-semibold">Design autoral</span>
          </div>
        </div>
        <footer className="mt-10 text-xs text-neutral-400">
          <p>@2025 TRIZ | Instagram | Contato | Política de Privacidade</p>
        </footer>
      </div>
    </div>
  )
}